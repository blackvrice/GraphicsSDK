"""Fail-closed acceptance for the bounded D3D12 memory campaign (not peak analysis)."""
import argparse
import hashlib
import json
import math
import pathlib
import re
import statistics

POLICY = pathlib.Path(__file__).with_name("memory_stress_policy.json")
OWNED = ("objects", "resources", "allocation_bytes", "pending", "pending_refs")
COUNTERS = ("frames", "rounds", *OWNED, "private_bytes", "working_set_bytes", "handles")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def number(value):
    return type(value) in (int, float) and math.isfinite(value)


def unique_object(pairs):
    result = {}
    for k, v in pairs:
        require(k not in result, "Duplicate JSON field: " + k)
        result[k] = v
    return result


def read_records(path):
    data = path.read_bytes()
    require(data.endswith(b"\n"), "Truncated JSONL evidence")
    return [json.loads(line, object_pairs_hook=unique_object) for line in data.decode("utf-8").splitlines()]


def validate_identity(header, footer, expected_adapter=None):
    """Schema 1 is historical; 2 binds identity; 3 adds public budget receipts."""
    require(type(header.get("schema")) is int and header["schema"] in (1, 2, 3), "Unknown evidence schema")
    require(type(header.get("luid_high")) is int and -(2**31) <= header["luid_high"] < 2**31
            and type(header.get("luid_low")) is int and 0 <= header["luid_low"] < 2**32, "Invalid LUID")
    identity = ((header["luid_high"] & 0xffffffff) << 32) | header["luid_low"]
    if header["schema"] == 1:
        require(expected_adapter is None, "Historical evidence cannot verify an explicit request")
        return identity
    for record, key in ((header, "adapter_id"), (header, "observer_adapter_id"), (footer, "adapter_id")):
        require(type(record.get(key)) is int and record[key] == identity, "SDK/observer/footer adapter identity mismatch")
    requested = header.get("requested_adapter_id")
    require("requested_adapter_id" in header and (requested is None or type(requested) is int and requested == identity), "Requested adapter identity mismatch")
    require(expected_adapter is None or type(expected_adapter) is int and requested == expected_adapter, "Explicit adapter request missing or changed")
    mode = header.get("mode")
    for key, value in (("software", mode == "warp"), ("gpu_validation", mode == "validation"), ("gpu_state_tracking", mode == "validation")):
        require(type(header.get(key)) is bool and header[key] == value, "Adapter kind/validation contract mismatch")
    require(type(header.get("private_growth_limit_bytes")) is int and 2**20 <= header["private_growth_limit_bytes"] <= 4096*2**20
            and type(header.get("guard_baseline_private_bytes")) is int and header["guard_baseline_private_bytes"] > 0, "Missing private growth guard")
    return identity


BUDGET_FIELDS = ("usage_bytes", "budget_bytes", "available_for_reservation_bytes", "reservation_bytes")
NATIVE_SUFFIXES = ("bytes", "budget", "available_for_reservation", "reservation")


def validate_budget_samples(records, policy=None):
    """Compare only stable independent native brackets; never invent a tolerance.

    Old schemas make no public-API claim. Dynamic/unstable brackets stay counted
    separately, and successful zero/over-budget values are legal uint64 snapshots.
    """
    h, footer = records[0], records[-1]
    if h["schema"] < 3:
        return {"recorded": False}
    policy = json.loads(POLICY.read_text()) if policy is None else policy
    identity = validate_identity(h, footer)
    result = {"recorded": True, "segments": {}}
    for segment in ("local", "nonlocal"):
        counts = dict(snapshots=0, available=0, unsupported=0, stable_native_matches=0, unstable_native_brackets=0)
        for sample in records[1:-1]:
            require(sample.get("type") == "sample", "Invalid budget checkpoint")
            sdk = sample.get("sdk_budget_" + segment)
            after = sample.get(f"gpu_{segment}_after")
            require(isinstance(sdk, dict) and isinstance(after, dict), "Missing SDK/native budget snapshot")
            require(all(n in sdk and n in after for n in BUDGET_FIELDS)
                    and all(f"gpu_{segment}_{n}" in sample for n in NATIVE_SUFFIXES), "Missing budget byte counter")
            require(type(sdk.get("adapter_id")) is int and sdk["adapter_id"] == identity
                    and sdk.get("segment") == segment, "SDK budget identity/segment mismatch")
            code = sdk.get("native_code")
            require(type(code) is int and -(2**63) <= code < 2**63, "Invalid SDK budget native code")
            first, last = sample.get(f"gpu_{segment}_hresult"), after.get("hresult")
            require(all(type(v) is int and -(2**31) <= v < 2**31 for v in (first, last)), "Invalid budget native HRESULT")
            before = dict(zip(BUDGET_FIELDS, (sample.get(f"gpu_{segment}_{n}") for n in NATIVE_SUFFIXES)))
            for status, values in ((first, before), (last, after)):
                require(all((status < 0 and values.get(n) is None) or
                            (status >= 0 and type(values.get(n)) is int and 0 <= values[n] < 2**64)
                            for n in BUDGET_FIELDS), "Native budget status/value mismatch")
            counts["snapshots"] += 1
            if sdk.get("status") == "unsupported":
                require(h["mode"] == "warp" and first == last == code and first < 0
                        and all(sdk.get(n) is None for n in BUDGET_FIELDS), "Unsupported SDK budget needs explicit failed WARP queries")
                require(code in (-2147467262, -2147467263, -2005270524), "Unexpected Unsupported budget HRESULT")
                counts["unsupported"] += 1
                continue
            require(sdk.get("status") == "ok" and code == 0, "Failed SDK budget query")
            require(first >= 0 and last >= 0, "Successful SDK budget needs native observations")
            require(all(type(sdk.get(n)) is int and 0 <= sdk[n] < 2**64 for n in BUDGET_FIELDS), "Invalid SDK budget byte counter")
            counts["available"] += 1
            if first == last and first >= 0 and all(before[n] == after[n] for n in BUDGET_FIELDS):
                require(all(sdk[n] == before[n] for n in BUDGET_FIELDS), "Stable native/SDK budget mapping mismatch")
                counts["stable_native_matches"] += 1
            else:
                counts["unstable_native_brackets"] += 1
        require(counts["snapshots"] > 0, "Missing budget checkpoints")
        require(not (counts["available"] and counts["unsupported"]), "Intermittent SDK budget support")
        require(not counts["available"] or counts["stable_native_matches"] > 0, "No stable native budget comparison")
        result["segments"][segment] = counts
    if h["mode"] != "warp":
        controls = {r.get("phase"): r for r in records[1:-1] if r.get("phase") in ("cpu_released", "gpu_held", "gpu_released")}
        require(len(controls) == 3, "Missing SDK budget retain/release controls")
        usage = {phase: r["sdk_budget_local"]["usage_bytes"] for phase, r in controls.items()}
        # Same positive-control threshold as the native observer, not a new policy.
        minimum = policy["hardware_gpu_control_minimum_usage_delta_bytes"]
        require(usage["gpu_held"] - max(usage["cpu_released"], usage["gpu_released"]) >= minimum,
                "SDK GPU usage retain/release control failed")
    return result


def analyze(records, expected_fingerprint, policy=None):
    policy = json.loads(POLICY.read_text()) if policy is None else policy
    require(len(records) >= 10, "Missing evidence records")
    h, f = records[0], records[-1]
    require(h.get("type") == "header" and f.get("type") == "footer", "Header/footer missing")
    identity = validate_identity(h, f)
    require(f.get("status") != "aborted" and not any(r.get("phase") == "guard_aborted" for r in records), "Memory growth guard aborted; incomplete soak")
    if h["schema"] >= 2:
        require(f.get("stop_reason") == "completed", "Incomplete native stop reason")
    budget_receipts = validate_budget_samples(records, policy)
    require(re.fullmatch(r"[a-f0-9]{64}", expected_fingerprint) is not None and h.get("sdk_sha256") == expected_fingerprint, "SDK source fingerprint mismatch")
    mode = h.get("mode")
    require(mode in policy["minimum_seconds"], "Unknown mode")
    require(type(h.get("seconds")) is int and h["seconds"] >= policy["minimum_seconds"][mode], "Short smoke is not soak acceptance")
    require(type(h.get("warmup")) is int and h["warmup"] >= policy["minimum_warmup_seconds"], "Insufficient warmup")
    require(type(h.get("interval")) is int and 1 <= h["interval"] <= 10, "Invalid sample interval")
    require(h.get("ring") == 8 and h.get("side") == 64 and h.get("copy_bytes") == 262144, "Workload contract mismatch")
    require(isinstance(h.get("adapter"), str) and h["adapter"] and type(h.get("luid_high")) is int and type(h.get("luid_low")) is int, "Missing adapter identity")
    samples = records[1:-1]
    previous = None
    for s in samples:
        require(s.get("type") == "sample" and number(s.get("elapsed")) and s["elapsed"] >= 0, "Invalid sample")
        for name in COUNTERS:
            require(type(s.get(name)) is int and s[name] >= 0, "Missing or invalid counter: " + name)
        require(s["frames"] == s["rounds"] * h["ring"], "Frame/round mismatch")
        for segment in ("local", "nonlocal"):
            result = s.get(f"gpu_{segment}_hresult")
            require(type(result) is int and -(2**31) <= result < 2**31, "Missing DXGI query status")
            for suffix in ("bytes", "budget"):
                value = s.get(f"gpu_{segment}_{suffix}")
                require((result < 0 and value is None) or (result >= 0 and type(value) is int and value >= 0), "DXGI status/value mismatch")
        if previous:
            require(s["elapsed"] >= previous["elapsed"] and s["frames"] >= previous["frames"], "Non-monotonic evidence")
        previous = s
    phases = [s["phase"] for s in samples]
    require(phases[:6] == ["baseline", "cpu_held", "cpu_released", "gpu_held", "gpu_released", "measurement_start"] and phases[-1] == "final", "Positive control/sample order mismatch")
    require(len(phases[6:-1]) % 2 == 0 and phases[6:-1] == ["live", "drained"] * (len(phases[6:-1]) // 2), "Incomplete live/drained pairs")
    baseline, cpu, cpu_released, gpu, released, start = samples[:6]
    for s in (baseline, cpu, cpu_released, released, start, samples[-1]):
        require(all(s[n] == 0 for n in OWNED), "Owned resources failed to return to baseline")
    require(cpu["private_bytes"] - baseline["private_bytes"] >= policy["cpu_control_minimum_delta_bytes"], "CPU observer positive control failed")
    require(cpu["private_bytes"] - cpu_released["private_bytes"] >= policy["cpu_control_minimum_delta_bytes"], "CPU control release not observed")
    require(gpu["objects"] == gpu["resources"] == 1 and gpu["allocation_bytes"] >= policy["gpu_control_minimum_allocation_bytes"] and gpu["pending"] == gpu["pending_refs"] == 0, "GPU ownership positive control failed")
    if mode != "warp":
        require(all(s["gpu_local_hresult"] >= 0 and s["gpu_nonlocal_hresult"] >= 0 for s in samples), "Hardware DXGI observation unavailable")
        delta = gpu["gpu_local_bytes"] - cpu_released["gpu_local_bytes"]
        release_delta = gpu["gpu_local_bytes"] - released["gpu_local_bytes"]
        require(min(delta, release_delta) >= policy["hardware_gpu_control_minimum_usage_delta_bytes"], "GPU usage retain/release control failed")
    require(start["elapsed"] - released["elapsed"] >= h["warmup"], "Warmup timing mismatch")
    require(f.get("status") == "passed" and f.get("statistics_contracts") is True and type(f.get("validation_errors")) is int and f["validation_errors"] == 0, "Missing successful native validation")
    require(number(f.get("measured_seconds")) and f["measured_seconds"] >= h["seconds"], "Incomplete measurement duration")
    require(number(f.get("elapsed")) and f["elapsed"] >= samples[-1]["elapsed"] and abs(f["elapsed"] - start["elapsed"] - f["measured_seconds"]) < 1, "Footer timing mismatch")
    require(f.get("frames") == samples[-1]["frames"] and f.get("full_images") == f["frames"] * 3 and f.get("verified_buffer_bytes") == f["frames"] * h["copy_bytes"], "Reference coverage mismatch")
    require(f["frames"] - start["frames"] >= h["seconds"] * policy["minimum_measured_frames_per_second"], "Insufficient measured work")
    drained = samples[7:-1:2]
    require(len(drained) >= h["seconds"] // h["interval"], "Missing measurement checkpoints")
    for live, drain in zip(samples[6:-1:2], drained):
        require(all(drain[n] == 0 for n in OWNED), "Drained SDK ownership is nonzero")
        require(live["resources"] >= h["ring"] * 4 and live["allocation_bytes"] >= live["resources"] * 65536, "Live resource observation did not see workload")
        require(drain["frames"] == live["frames"] + h["ring"], "Checkpoint reference verification mismatch")
    times = [start["elapsed"], *[s["elapsed"] for s in drained], samples[-1]["elapsed"]]
    require(all(b - a <= policy["maximum_sample_gap_seconds"] for a, b in zip(times, times[1:])), "Checkpoint gap exceeds policy")
    require(samples[-1]["elapsed"] - start["elapsed"] >= h["seconds"], "Final sample before campaign end")
    tail = [s for s in drained if s["elapsed"] >= start["elapsed"] + h["seconds"] * (1 - policy["tail_fraction"])]
    require(len(tail) >= 8, "Insufficient plateau observations")
    metrics = {}
    for name, limits in policy["limits"].items():
        values = [s[name] for s in tail]
        if any(v is None for v in values):
            require(mode == "warp" and name.startswith("gpu_") and all(v is None for v in values), "Intermittent missing memory metric")
            metrics[name] = {"supported": False}
            continue
        x = [(s["elapsed"] - tail[0]["elapsed"]) / 60 for s in tail]
        xm, ym = statistics.mean(x), statistics.mean(values)
        slope = sum((a-xm)*(b-ym) for a, b in zip(x, values)) / sum((a-xm)**2 for a in x)
        quarter = max(2, len(values)//4)
        drift = statistics.median(values[-quarter:]) - statistics.median(values[:quarter])
        spread = max(values) - min(values)
        require(drift <= limits["median_drift"] and slope <= limits["slope_per_minute"] and spread <= limits["range"], "Memory plateau gate failed: " + name)
        metrics[name] = {"supported": True, "median_drift": drift, "slope_per_minute": slope, "range": spread, "tail_checkpoint_maximum": max(values)}
    return {"mode": mode, "adapter_id": identity, "accepted": True, "measured_seconds": f["measured_seconds"], "frames": f["frames"], "full_images": f["full_images"], "verified_buffer_bytes": f["verified_buffer_bytes"], "drained_samples": len(drained), "tail_samples": len(tail), "owned_after_drain": 0, "metrics": metrics, "public_memory_budget": budget_receipts}


def validate_campaign(results):
    require(sorted(r["mode"] for r in results) == ["gpu", "validation", "warp"], "Exactly one campaign per mode required")
    by_mode = {r["mode"]: r for r in results}
    require(by_mode["gpu"]["adapter_id"] == by_mode["validation"]["adapter_id"]
            and by_mode["gpu"]["adapter_id"] != by_mode["warp"]["adapter_id"], "Mixed campaign adapter identities")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("inputs", nargs="+", type=pathlib.Path)
    p.add_argument("--fingerprint", required=True)
    p.add_argument("--output", required=True, type=pathlib.Path)
    args = p.parse_args()
    results = [analyze(read_records(path), args.fingerprint) for path in args.inputs]
    validate_campaign(results)
    result = {"accepted": True, "policy_sha256": hashlib.sha256(POLICY.read_bytes()).hexdigest(), "SDK_source_fingerprint": args.fingerprint, "continuous_peak_claim": False, "campaigns": results}
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("PASS: bounded memory campaign acceptance, all three modes")


if __name__ == "__main__":
    main()
