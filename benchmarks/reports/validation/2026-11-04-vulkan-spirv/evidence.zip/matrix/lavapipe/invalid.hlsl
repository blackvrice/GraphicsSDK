float4 broken() : SV_Target0 { return missingSymbol; }
