#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct gfx_fragment_out
{
    float4 out_var_SV_Target0 [[color(0)]];
};

fragment gfx_fragment_out gfx_fragment()
{
    gfx_fragment_out out = {};
    out.out_var_SV_Target0 = float4(1.0, 0.25, 0.0, 1.0);
    return out;
}

