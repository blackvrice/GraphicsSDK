#include <metal_stdlib>
using namespace metal;
fragment float4 gfx_fragment() { return missingSymbol; }
