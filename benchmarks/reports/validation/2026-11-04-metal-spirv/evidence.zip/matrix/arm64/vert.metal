#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct gfx_vertex_out
{
    float4 gl_Position [[position]];
};

vertex gfx_vertex_out gfx_vertex(uint gl_VertexIndex [[vertex_id]])
{
    gfx_vertex_out out = {};
    out.gl_Position = float4((float2(float((gl_VertexIndex << 1u) & 2u), float(gl_VertexIndex & 2u)) * 2.0) - float2(1.0), 0.0, 1.0);
    return out;
}

